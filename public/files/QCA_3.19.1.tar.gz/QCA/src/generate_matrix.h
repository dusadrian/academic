#include "utils.h"

void generate_matrix(
    int nrows,
    int ncols,
    int nofl[],
    int arrange,
    int maxprod,
    int *p_matrix
);

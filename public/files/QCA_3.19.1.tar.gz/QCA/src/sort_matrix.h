#include <stdbool.h>

void sort_matrix(
    int *p_matrix,
    int *p_colindx,
    int *p_ck,
    int nconds,
    unsigned int foundPI
);

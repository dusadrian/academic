#include <stdbool.h>

void row_dominance(
    int p_pichart[],
    int p_implicants[],
    int *p_ck,
    int pirows,
    unsigned int *foundPI,
    int nconds
);

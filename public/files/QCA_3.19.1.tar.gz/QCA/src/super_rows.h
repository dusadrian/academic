#include <stdbool.h>

void super_rows(
    int *p_matrix,
    int rows,
    unsigned int *survcols,
    int *p_cols
);

#include <stdbool.h>

void sort_cols(
    int *p_matrix,
    int *p_sortcol,
    int *p_ck,
    int nconds,
    unsigned int foundPI
);

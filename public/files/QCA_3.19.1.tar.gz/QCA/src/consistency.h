double consistency(
    const double p_x[],
    const int nrowsx,
    const int nconds,
    int k,
    int tempk[],
    int val[],
    int fuzzy[]
);

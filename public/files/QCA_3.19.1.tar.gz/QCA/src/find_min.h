
void find_min(
    const int p_pichart[],
    const int pirows,           // the minterms
    const unsigned int picols,  // the PIs
    int *solmin,                // scalar, the solution minima to be found
    int p_indices[]             // positions of the PIs which solve the PI chart
);
